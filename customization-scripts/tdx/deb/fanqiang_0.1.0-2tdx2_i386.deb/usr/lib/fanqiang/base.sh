#!/bin/bash

# 功能：自动启动翻墙软件，判断翻墙软件是否翻墙成功，若成功后自动设置火狐代理，并自动打开火狐浏览。（若火狐已经在运行，为防止直接连被封锁网站，不自动打开火狐，仅显示提示窗口）

# DONE 支持自由门
# DONE 支持无界浏览
# DONE 防止运行多个实例、重复启动
# TODO 翻墙超时后，自动检查自由门進程是否zombie，自动重启
# TODO 支持其它翻墙软件
# DONE 选择自由门或其它翻墙软件的版本
# TODO 本脚本的多语言支持
# DONE 不允许root帐号运行本脚本
# DONE 未考虑若wine从未运行过不存在 .wine 的情况
# DONE 第一次启动时比较慢，可以先给个提示窗口
# TODO 退出自由门时，提示取消IE代理失败
# TODO 由live CD脚本把live帐号从sudo中去掉，设置live帐号的Firefox配置文件为只读，所有者和group为root，mod为 644，测试了，无效，Firefox退出后所有者和group都自动还原了。
# 再配合系统全局Firefox配置 /etc/firefox/syspref.js ，可保证用户无法更改代理配置，可以尝试用apparmor
# TODO 如果翻墙超时，自动尝试逐个启动其它版本的
# TODO 把翻墙软件和签名文件放到rootfs外面，ISO镜像内，或优盘中，Live系统启动时自动查找、检验并启动最新版本。这样翻墙软件升级但Live系统没有升级，就不需要从新打包filesystem.squashfs文件
# TODO 火狐的配置文件、测试翻墙的URL、自动打开的主页、书签等配置都可以采用上述方法
# TODO 升级flash player也可以采用上述方法

#用于测试翻墙是否成功的网站，仅限于http,https,ftp协议，否则会导致误判
#TODO 如果测试网站挂了就会误判，解决办法是用多个网址测试，任何一个成功就表示翻墙成功
FG_TEST_SITE="www.minghui.org"

#翻墙成功后自动打开的主页URL
FG_HOME_SITE="www.minghui.org"

#翻墙成功后自动打开的主页名称
FG_HOME_NAME="明慧网"

#全局变量定义

#翻墙启动脚本所需exe,dll,ini等配置文件安装目录，用户不能修改
FG_SHARE_DIR="/usr/share/fanqiang"

#翻墙软件進程id
FG_PID=0

WINE=$( which true-wine || which wine)

#函数定义

check_user() {
    if [[ $UID == 0 ]] ; then
        echo "本程序不允许在root帐号下运行！"
        exit 1
    fi
}

#检查传入的环境变量
check_param () {
    if [[ "$FG_NAME" == "" ]] ; then
        echo "请设置翻墙软件名称。"
        exit 4
    fi

    if [[ "$FG_PORT" == "" ]] ; then
        echo "请设置翻墙软件端口。"
        exit 4
    fi

    #判断 FG_PORT 是否都是数字
    if [[ -n ${FG_PORT//[0-9]/} ]]; then
        echo "请设置正确的翻墙软件端口，必须为整数。"
        exit 4
    fi

    #判断 FG_PORT 大小是否合格
    if [ $FG_PORT -gt 65535 2>/dev/null ]
    then
        echo "翻墙软件端口必须小于65536。"
        exit 4
    fi

    if [ $FG_PORT -lt 1024 2>/dev/null ]
    then
        echo "翻墙软件端口必须大于1023。"
        exit 4
    fi

    #翻墙软件翻墙超时的大概秒数，默认300秒
    if [[ "$FG_TIMEOUT" == "" ]] ; then
        FG_TIMEOUT=300
    fi

    #判断 FG_TIMEOUT 是否都是数字
    if [[ -n ${FG_TIMEOUT//[0-9]/} ]]; then
        echo "请设置正确的翻墙软件端口，必须为整数。"
        exit 4
    fi

    #判断 FG_TIMEOUT 大小是否合格
    if [ $FG_TIMEOUT -gt 1800 2>/dev/null ]
    then
        echo "翻墙软件翻墙超时必须小于1800。"
        exit 4
    fi

    if [ $FG_TIMEOUT -lt 30 2>/dev/null ]
    then
        echo "翻墙软件翻墙超时必须大于30。"
        exit 4
    fi

    if [[ "$FG_EXE" == "" ]] ; then
        FG_EXE="`basename $0`.exe"
    fi
}

#搜索exe文件
find_exe () {
    FG_FULL="$FG_SHARE_DIR/$FG_EXE"
    if [[ ! -e "$FG_FULL" ]] ; then
        FG_FULL="/cdrom/fanqiang/$FG_EXE"
        if [[ ! -e "$FG_FULL" ]] ; then
            if [[ "$EXE_DIR" == "" ]] ; then
                EXE_DIR="`dirname "$FG_DIR"`/.exe"
            fi
            FG_FULL=`find "$EXE_DIR" -maxdepth 1 -name "$FG_EXE"`
            if [[ ! -e "$FG_FULL" ]] ; then
                echo "找不到$FG_NAME的exe文件。"
                notify-send "错误提示" "真遗憾！ 找不到$FG_NAME的exe文件。\n请拷贝$FG_EXE文件到“$EXE_DIR”目录中。" &
                exit 5
            fi
        fi
    fi
}

#验证EXE文件签名
# VAR=`cmd`,虽然 cmd 返回多行，但 echo $VAR 还是一行
sig_check() {
    SIG_FILE="/tmp/$FG_EXE.sig"
    $WINE sigcheck -i "./$FG_EXE" | tr -d '\r' > "$SIG_FILE"
    SIGNED=0
    if head -n 2 "$SIG_FILE" | tail -n 1 | grep 'Verified.*Signed' ; then
        SIGNED=1
    fi
    if (( $SIGNED == 1 )) ; then
        MATCH=0
        for F in 1108786E4D8A1CE50E00112BBD9D0499EAA5A383 DAAE4E72890907E7ED35130F6126CAF5429E142B 0329A20BFC9362749572E833343760F0AEC2EF64 ; do
            if grep -m 1 -Pzo "Signers:.*\\n.*Dynamic Internet Technology Inc\..*\\n.*\\n.*\\n.*\\n.*\\n.*Thumbprint:.*$F" "$SIG_FILE" ; then
                MATCH=1
                break
            fi
        done

        if (( $MATCH == 0 )) ; then
            for F in 4AA357AFD57098EBB60FED7235E22CCD64E2AFA7 B009C8B2E0F35548897A347CA6BF360469035CC5 ; do
                if grep -m 1 -Pzo "Signers:.*\\n.*Ultrareach Internet Corp\..*\\n.*\\n.*\\n.*\\n.*\\n.*Thumbprint:.*$F" "$SIG_FILE" ; then
                    MATCH=1
                    break
                fi
            done
            if (( $MATCH == 0 )) ; then
                notify-send "错误..." "${FG_EXE}文件的签名证书不在已知名单内，程序退出。" &
                exit 12
            fi
        fi

        MATCH=0
        for F in 'Dynamic Internet Technology Inc\.' 'Ultrareach Internet Corp\.' ; do
            if grep -m 1 "Publisher:.*$F" "$SIG_FILE" ; then
                MATCH=1
                break
            fi
        done
        if (( $MATCH == 0 )) ; then
            notify-send "错误..." "${FG_EXE}文件的发行商未知，程序退出。" &
            exit 12
        fi
    else
        notify-send "错误..." "${FG_EXE}文件未签名，程序退出。" &
        exit 12
    fi
}

#创建windows目录
mk_win_dirs() {
    mkdir -p ~/.wine/drive_c/windows/system32/
    #mkdir -p ~/.wine/drive_c/windows/winsxs/x86_microsoft.windows.common-controls_6595b64144ccf1df_6.0.2600.2982_none_deadbeef/
}

#创建指向fakedlls的符号链接
mk_symbol() {
    #cp -sf /usr/lib/i386-linux-gnu/wine/fakedlls/*  ~/.wine/drive_c/windows/system32/
    #rm ~/.wine/drive_c/windows/system32/explorer.exe
    #cp -sf /usr/lib/i386-linux-gnu/wine/fakedlls/explorer.exe  ~/.wine/drive_c/windows/
    #cp -sf /usr/lib/i386-linux-gnu/wine/fakedlls/comctl32.dll ~/.wine/drive_c/windows/winsxs/x86_microsoft.windows.common-controls_6595b64144ccf1df_6.0.2600.2982_none_deadbeef/
    #cp -sf /usr/share/wine/l_intl.nls ~/.wine/drive_c/windows/system32/
    cp -sf /usr/share/wine/mfc42.dll ~/.wine/drive_c/windows/
    cp -sf /usr/share/wine/sigcheck.exe ~/.wine/drive_c/windows/system32/
}

#启动翻墙软件
fg_start () {
    echo 启动翻墙软件
    # kill 可能存在的未响应的翻墙软件進程 TODO 只需要 kill zombie 進程
    # killall $FG_EXE

    # 启动新的翻墙软件進程  
    # DONE 使用软链接代替拷贝。
    # TODO 或者用rsync强制检查目标文件是否与原始文件相符
    export WINEDLLOVERRIDES="mscoree,mshtml="
    FG_WIN_DIR="$HOME/.wine/drive_c/windows"
    if [[ ! -e "$FG_WIN_DIR" ]] ; then
        mk_win_dirs
        mk_symbol
        wineboot
        # 使sigcheck没有Eula的提示
        wine reg.exe ADD HKCU\\Software\\Sysinternals\\SigCheck /v EulaAccepted /t REG_DWORD /d 1 /f
    else
        mk_symbol
    fi
    #防止翻墙软件启动Wine Iexplorer
    rm -f "$HOME/.wine/drive_c/Program Files/Internet Explorer/iexplore.exe"
    rm -f "$HOME/.wine/drive_c/Program Files (x86)/Internet Explorer/iexplore.exe"
    cd "$FG_SHARE_DIR"
    find_exe
    cp -sf "$FG_FULL" "$FG_WIN_DIR"
    cp -u fg.ini "$FG_WIN_DIR"
    cp -u dtwpc.dat "$FG_WIN_DIR"
    cp -u u.ini "$FG_WIN_DIR"
    cp -u dp.ini "$FG_WIN_DIR"
    cd "$FG_WIN_DIR"
    sig_check
    $WINE ./$FG_EXE &
    FG_PID=$!
    echo "翻墙软件進程id:$FG_PID"
}

#翻墙软件進程在翻墙成功之前终止时给出提示并退出
fg_stop () {
    notify-send "提示..." "${FG_NAME}進程终止，但是翻墙没有成功，\n若不是您主动关闭的，\n请您从新启动${FG_NAME}。" &
    exit 8
}

#翻墙超时，显示错误提示
fg_error () {
    echo 显示翻墙超时错误提示
    notify-send "翻墙超时" "真遗憾！ $FG_NAME 翻墙超时了，请稍后再试。\n或检查您的网络连接是否正常。" &
}

#浏览器進程数
fg_firefox_proc_count () {
    FG_FIREFOX_PROC_COUNT=$( ps u -C firefox | grep "^$USER " | wc -l )
    echo 浏览器進程数=$FG_FIREFOX_PROC_COUNT
}

#翻墙软件端口是否打开
fg_is_listen () {
    let FG_PORT_PLUS=FG_PORT+1
    netstat -tnlp $FG_PID | grep :$FG_PORT_PLUS.*wineserver
    if (( $? == 0 )) ; then
        FG_LISTEN=1
        let FG_PORT=FG_PORT_PLUS
        echo "$FG_NAME 已经打开 $FG_PORT 端口"
    else
        netstat -tnlp $FG_PID | grep :$FG_PORT.*wineserver
        if (( $? == 0 )) ; then
            FG_LISTEN=1
            echo "$FG_NAME 已经打开 $FG_PORT 端口"
        else
            FG_LISTEN=0
        fi
    fi
}

#设置firefox代理
fg_set_firefox_proxy () {
    echo 正在设置firefox代理
    #若火狐没有运行过，则生成火狐配置文件
    if ! [[ -e "$HOME/.mozilla/firefox" ]] ; then
        PROFILE=`cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1`
        PROFILE=${PROFILE,,}.default
        mkdir -p "$HOME/.mozilla/firefox/$PROFILE"
        echo > "$HOME/.mozilla/firefox/$PROFILE/prefs.js"
cat > "$HOME/.mozilla/firefox/$PROFILE/profiles.ini" <<EOF
[General]
StartWithLastProfile=1

[Profile0]
Name=default
IsRelative=1
Path=$PROFILE
EOF
    fi
    #get the current gproxy id,let gproxy tool displsy the right proxy
    case $FG_PORT in
        8580 | 8581 )
            CURRENT_GPROXY_ID="gproxy_108294";;
        9666 | 9667 | 433)
            CURRENT_GPROXY_ID="gproxy_2914";;
        8000)
            CURRENT_GPROXY_ID="gproxy_10612";;
        8081)
            CURRENT_GPROXY_ID="gproxy_171534";;
    esac

    for F in $( find "$HOME/.mozilla/firefox" -iname "prefs*.js" ) ; do
        if sed "s/8580/${FG_PORT}/g" "$FG_SHARE_DIR/syspref.js" | sed "s/gproxy_${FG_PORT}/${CURRENT_GPROXY_ID}/g" >> "$F" ; then
            FG_SET_PROXY_OK=1
        fi
    done
}

#启动浏览器
fg_start_browser () {
    fg_firefox_proc_count
    if (( $FG_FIREFOX_PROC_COUNT <= 0 )) ; then
        FG_SET_PROXY_OK=0
        fg_set_firefox_proxy
        if (( $FG_SET_PROXY_OK == 1 )) ; then
            echo 启动浏览器
            notify-send "翻墙成功" "恭喜您，$FG_NAME 翻墙成功了！\n正在打开浏览器准备浏览$FG_HOME_NAME。\n请耐心等待。" &
            firefox -private "$FG_HOME_SITE" &   # TODO  -private 参数似乎没有起作用，历史里面还有，也没有显示隐私浏览的图标
        else
            echo 设置浏览器代理失败
            notify-send "翻墙成功" "恭喜您，$FG_NAME 翻墙成功了！\n但是设置浏览器代理失败，这有可能是下列原因：\n用户目录下剩余空间不足；\n用户目录所在文件系统存在错误；\n用户目录文件权限设置不当。" &
        fi
    else
        echo "浏览器已经在运行，不必再启动"   #避免直接访问墙外网站
        notify-send "翻墙成功" "恭喜您，$FG_NAME 翻墙成功了！\n请设置浏览器代理服务器为 127.0.0.1:$FG_PORT 后再浏览墙外网站。" &
    fi
}

#比较自由门版本
get_max_fg () {
    if [ -n "$F" ] ; then
        V=${F:2:3}
        if (( "$V" > "$MAX" )) ; then
            MAX=$V
            echo $MAX
        fi
    fi
}

#计算需要下载的自由门版本
ver_fg () {
    MAX="721"
    DOT_EXE_DIR="`dirname "$FG_DIR"`/.exe"
    F=$(basename `find $DOT_EXE_DIR -maxdepth 1 -name "fg???${FG_MODE}.exe" | sort | tail -n1`)
    get_max_fg

    F=$(basename `find /cdrom/fanqiang -maxdepth 1 -name "fg???${FG_MODE}.exe" | sort | tail -n1`)
    get_max_fg

    F=$(basename `find $FG_SHARE_DIR -maxdepth 1 -name "fg???${FG_MODE}.exe" | sort | tail -n1`)
    get_max_fg
}

#比较无界浏览版本
get_max_u () {
    if [ -n "$F" ] ; then
        V=${F:1:4}
        if (( "$V" > "$MAX" )) ; then
            MAX=$V
            echo $MAX
        fi
    fi
}

#计算需要下载的无界浏览版本
ver_u () {
    MAX="1201"
    DOT_EXE_DIR="`dirname "$FG_DIR"`/.exe"
    F=$(basename `find $DOT_EXE_DIR -maxdepth 1 -name "u????.exe" | sort | tail -n1`)
    get_max_u

    F=$(basename `find /cdrom/fanqiang -maxdepth 1 -name "u????.exe" | sort | tail -n1`)
    get_max_u

    F=$(basename `find $FG_SHARE_DIR -maxdepth 1 -name "u????.exe" | sort | tail -n1`)
    get_max_u
}

#生成自由门限制版启动脚本
gen_fg_bin () {
    echo "gen_fg_bin $1"
    BIN="$BIN_DIR/fg${1}r"
    VER=${1:0:1}.${1:1}
    echo $VER
    cat > "$BIN" <<EOF
#!/bin/bash

export FG_MODE="r"
export FG_MODETEXT="限制版"
export FG_NAME="自由门${VER}限制版"
export FG_PORT=8580
export FG_TIMEOUT=300    #翻墙软件翻墙超时的大概秒数

. /usr/lib/fanqiang/base.sh
EOF
    chmod +x "$BIN"
}

#生成自由门限制版启动图标
gen_fg_desktop () {
    echo "gen_fg_desktop $1"
    ICO="$ICO_DIR/fg${1}r.desktop"
    cat > "$ICO" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Freegate ${VER} Restricted
Name[zh_CN]=自由门${VER}限制版
Comment=Use Freegate To Browse Web Sites Which Blocked In Mainland China
Comment[zh_CN]=使用自由门翻墙，看被大陆封锁的网站

Keywords=Internet;WWW;Browser;Web;Explorer;Freegate;dongtaiwang;antiGFW;proxy;antiblock
Keywords[zh_CN]=Internet;WWW;Browser;Web;Explorer;Freegate;dongtaiwang;antiGFW;proxy;antiblock;网页;浏览;上网;火狐;Firefox;ff;互联网;网站;翻墙;破网;防火墙;动态网;自由门;代理;突破封锁

Exec=$BIN_DIR/fg${1}r
Icon=/usr/share/fanqiang/fg.png
Categories=Freegate;
Path=
Terminal=false
X-MultipleArgs=false
StartupNotify=true
EOF
    chmod +x "$ICO"
}

#生成自由门专家版启动脚本
gen_fgx_bin () {
    echo "gen_fgx_bin $1"
    BIN="$BIN_DIR/fg${1}x"
    VER=${1:0:1}.${1:1}
    echo $VER
    cat > "$BIN" <<EOF
#!/bin/bash

export FG_MODE="x"
export FG_MODETEXT="专家版"
export FG_NAME="自由门${VER}专家版"
export FG_PORT=8580
export FG_TIMEOUT=300    #翻墙软件翻墙超时的大概秒数

. /usr/lib/fanqiang/base.sh
EOF
    chmod +x "$BIN"
}

#生成自由门专家版启动图标
gen_fgx_desktop () {
    echo "gen_fgx_desktop $1"
    ICO="$ICO_DIR/fg${1}x.desktop"
    cat > "$ICO" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Freegate ${VER} Experts
Name[zh_CN]=自由门${VER}专家版
Comment=Use Freegate To Browse Web Sites Which Blocked In Mainland China
Comment[zh_CN]=使用自由门翻墙，看被大陆封锁的网站

Keywords=Internet;WWW;Browser;Web;Explorer;Freegate;dongtaiwang;antiGFW;proxy;antiblock
Keywords[zh_CN]=Internet;WWW;Browser;Web;Explorer;Freegate;dongtaiwang;antiGFW;proxy;antiblock;网页;浏览;上网;火狐;Firefox;ff;互联网;网站;翻墙;破网;防火墙;动态网;自由门;代理;突破封锁

Exec=$BIN_DIR/fg${1}x
Icon=/usr/share/fanqiang/fg.png
Categories=Freegate;
Path=
Terminal=false
X-MultipleArgs=false
StartupNotify=true
EOF
    chmod +x "$ICO"
}

#生成自由门专业版启动脚本
gen_fgp_bin () {
    echo "gen_fgp_bin $1"
    BIN="$BIN_DIR/fg${1}p"
    VER=${1:0:1}.${1:1}
    echo $VER
    cat > "$BIN" <<EOF
#!/bin/bash

export FG_MODE="p"
export FG_MODETEXT="专业版"
export FG_NAME="自由门${VER}专业版"
export FG_PORT=8580
export FG_TIMEOUT=300    #翻墙软件翻墙超时的大概秒数

. /usr/lib/fanqiang/base.sh
EOF
    chmod +x "$BIN"
}

#生成自由门专业版启动图标
gen_fgp_desktop () {
    echo "gen_fgp_desktop $1"
    ICO="$ICO_DIR/fg${1}p.desktop"
    cat > "$ICO" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Freegate ${VER} Professional
Name[zh_CN]=自由门${VER}专业版
Comment=Use Freegate To Browse Web Sites Which Blocked In Mainland China
Comment[zh_CN]=使用自由门翻墙，看被大陆封锁的网站

Keywords=Internet;WWW;Browser;Web;Explorer;Freegate;dongtaiwang;antiGFW;proxy;antiblock
Keywords[zh_CN]=Internet;WWW;Browser;Web;Explorer;Freegate;dongtaiwang;antiGFW;proxy;antiblock;网页;浏览;上网;火狐;Firefox;ff;互联网;网站;翻墙;破网;防火墙;动态网;自由门;代理;突破封锁

Exec=$BIN_DIR/fg${1}p
Icon=/usr/share/fanqiang/fg.png
Categories=Freegate;
Path=
Terminal=false
X-MultipleArgs=false
StartupNotify=true
EOF
    chmod +x "$ICO"
}

#生成无界浏览启动脚本
gen_u_bin () {
    echo "gen_u_bin $1"
    BIN="$BIN_DIR/u${1}"
    VER=${1:0:2}.${1:2}
    echo $VER
    cat > "$BIN" <<EOF
#!/bin/bash

 export FG_NAME="无界浏览$VER"
 export FG_PORT=9666
 export FG_TIMEOUT=300    #翻墙软件翻墙超时的大概秒数

. /usr/lib/fanqiang/base.sh
EOF
    chmod +x "$BIN"
}

#生成无界浏览启动图标
gen_u_desktop () {
    echo "gen_u_desktop $1"
    ICO="$ICO_DIR/u${1}.desktop"
    cat > "$ICO" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Ultrasurf $VER
Name[zh_CN]=无界浏览$VER
Comment=Use Ultrasurf To Browse Web Sites Which Blocked In Mainland China
Comment[zh_CN]=使用无界浏览翻墙，看被大陆封锁的网站

Keywords=Internet;WWW;Browser;Web;Explorer;Ultrasurf;UltraReach;antiGFW;proxy;antiblock
Keywords[zh_CN]=Internet;WWW;Browser;Web;Explorer;Ultrasurf;UltraReach;antiGFW;proxy;antiblock;网页;浏览;上网;火狐;Firefox;ff;互联网;网站;翻墙;破网;防火墙;无界浏览;代理;突破封锁

Exec=$BIN_DIR/u${1}
Icon=/usr/share/fanqiang/u.png
Categories=GNOME;GTK;Network;WebBrowser;
Path=
Terminal=false
X-MultipleArgs=false
StartupNotify=true
EOF
    chmod +x "$ICO"
}

#下载最新版的自由门和无界浏览，生成启动脚本和图标
fg_upgrade () {
    echo 开始下载最新版的自由门和无界浏览
    export http_proxy="127.0.0.1:$FG_PORT"
    EXE_DIR="$ICO_DIR/.exe"
    BIN_DIR="$ICO_DIR/.bin"
    echo "$EXE_DIR"
    cd "$EXE_DIR"

    ver_fg
    let V=MAX+1
    let MAX=V+5
    for (( ; V < MAX; V++ )) ; do
        if [[ -e fg${V}${FG_MODE}.exe ]] ; then
            continue
        fi
        URL="http://dongtaiwang.com/loc/software/fg/$V/fg${V}${FG_MODE}.zip"
        VER=${V:0:1}.${V:1}
        if wget -c "$URL" ; then
            if unzip -oq fg${V}${FG_MODE}.zip ; then
                case ${FG_MODE} in
                    "r" | "R")
                        gen_fg_bin $V
                        gen_fg_desktop $V;;
                    "x"	| "X")
                        gen_fgx_bin $V
                        gen_fgx_desktop $V;;
                    "p" | "P")
                        gen_fgp_bin $V
                        gen_fgp_desktop $V;;
                    *) 
                        echo "ERROR";;
                esac
                notify-send "提示信息" "自由门${VER}${FG_MODETEXT}下载安装成功！" &
            else
                rm -f fg${V}${FG_MODE}.zip
                rm -f fg${V}${FG_MODE}.exe
            fi
        fi
    done

    if ! wget -O wujiliulan_download.html http://wujieliulan.com/download.php ; then
        return
    fi
    ver_u
    for F in $( grep -o u[0-9][0-9][0-9][0-9]*\.zip wujiliulan_download.html | sort | uniq ); do
        V=$(echo $F | grep -o [0-9]*)
        if [[ -e u${V}.exe ]] ; then
            continue
        fi
        if (( "$V" <= $"MAX" )) ; then
            continue
        fi
        URL="http://wujieliulan.com/download/u$V.zip"
        VER=${V:0:2}.${V:2}
        #下载无界浏览时，若zip文件不存在的话，网站重定向到另外一个网页，wget和curl都判断不了
        if wget -c "$URL" ; then
            if unzip -oq u$V.zip ; then
                gen_u_bin $V
                gen_u_desktop $V
                rm u$V.zip
                notify-send "提示信息" "无界浏览${VER}下载安装成功！" &
            else
                rm -f u$V.zip
                rm -f u$V.exe
            fi
        fi
    done
    rm wujiliulan_download.html
    killall -TERM mate-notification-daemon
    killall -TERM notification-daemon
    killall -TERM xfce4-notifyd
}

#---------------------------------程序主体开始---------------------------------

check_user
check_param

#防止notify-send命令失效
killall -TERM mate-notification-daemon
killall -TERM notification-daemon
killall -TERM xfce4-notifyd

# 只允许一个实例运行，摘自： https://gist.github.com/przemoc/571091
# 删除了，自由门自己能判断是否重复启动

#获取翻墙启动脚本所在目录，自动判断
pushd `dirname $0` > /dev/null
FG_DIR=`pwd -P`
popd > /dev/null
ICO_DIR=`dirname "$FG_DIR"`
echo FG_DIR=$FG_DIR
echo ICO_DIR=$ICO_DIR
if ! [[ "`basename "$FG_DIR"`" == ".bin" ]] ; then
    notify-send "错误提示" "启动脚本必须放在 .bin 目录中。" &
    exit 10
fi

echo $$ > "/tmp/`basename $0`.pid"

fg_firefox_proc_count
if (( $FG_FIREFOX_PROC_COUNT <= 0 )) ; then
    notify-send "为您努力翻墙中..." "正在启动 $FG_NAME，请等待。\n翻墙成功会自动打开火狐浏览$FG_HOME_NAME。" &
else
    notify-send "为您努力翻墙中..." "正在启动 $FG_NAME，请等待。\n火狐正在运行中，翻墙成功后您需要手动设置火狐代理。" &
fi

fg_start

#超时之前提前退出脚本
fg_exit () {
    echo 超时之前提前退出
    if (( $FG_LISTEN == 0 )) ; then
        kill -TERM $FG_PID
        exit 7
    fi
}

fg_del_pid () {
    rm -f "/tmp/`basename $0`.pid"
}

trap fg_exit TERM;
trap fg_del_pid EXIT;

TRY_COUNT=0
FG_LISTEN=0
while true; do
    if (( $FG_LISTEN == 0 )) ; then
        if ps $FG_PID > /dev/null ; then
            fg_is_listen
            if (( $FG_LISTEN == 1 )) ; then
                continue
            fi
        else    #若翻墙软件進程不存在，则退出。
            fg_stop
            break
        fi
        sleep 1
        let TRY_COUNT++
        continue
    fi
    if ps $FG_PID > /dev/null ; then
        export http_proxy="127.0.0.1:$FG_PORT"
        export https_proxy="127.0.0.1:$FG_PORT"
        export ftp_proxy="127.0.0.1:$FG_PORT"
        wget -O - --spider "$FG_TEST_SITE" > /dev/null
        FG_WGET_EXIT=$?
        if (( $FG_WGET_EXIT == 0 || $FG_WGET_EXIT >= 5 )) ; then   #翻墙成功，启动火狐
            echo "翻墙成功"
            fg_start_browser
            fg_upgrade &
            exit
        else
            #https://tiandixing.org/viewtopic.php?f=86&t=156752#p876880
            #if (( $FG_WGET_EXIT == 1 || $FG_WGET_EXIT == 4 )) ; then   #若拒绝连接，则退出。
            #    fg_stop
            #    break
            #fi
            sleep 1
            let TRY_COUNT++
            if (( $TRY_COUNT >= $FG_TIMEOUT )) ; then   #翻墙超时，则退出
                fg_error
                kill -TERM $FG_PID
                sleep 5
                killall $FG_EXE
                exit 3
            fi
        fi
    else    #若翻墙软件進程不存在，则退出。
        fg_stop
        break
    fi
done

#---------------------------------程序主体结束---------------------------------

# 参考：
# http://www.gnu.org/software/wget/manual/html_node/Exit-Status.html
